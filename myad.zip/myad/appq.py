import pandas as pd

# Load dataset
df = pd.read_csv("Amazon Sales data.csv", encoding='latin-1')

# Print all column names
print("Available columns in dataset:", df.columns.tolist())